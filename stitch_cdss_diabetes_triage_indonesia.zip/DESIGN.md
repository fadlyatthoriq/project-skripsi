---
name: Clinical Clarity System
colors:
  surface: '#faf8ff'
  surface-dim: '#d9d9e5'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3fe'
  surface-container: '#ededf9'
  surface-container-high: '#e7e7f3'
  surface-container-highest: '#e1e2ed'
  on-surface: '#191b23'
  on-surface-variant: '#434655'
  inverse-surface: '#2e3039'
  inverse-on-surface: '#f0f0fb'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#943700'
  on-tertiary: '#ffffff'
  tertiary-container: '#bc4800'
  on-tertiary-container: '#ffede6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#ffdbcd'
  tertiary-fixed-dim: '#ffb596'
  on-tertiary-fixed: '#360f00'
  on-tertiary-fixed-variant: '#7d2d00'
  background: '#faf8ff'
  on-background: '#191b23'
  surface-variant: '#e1e2ed'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  data-mono:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  2xl: 48px
  container-max: 1440px
  gutter: 24px
  margin-mobile: 16px
---

## Brand & Style

The design system is engineered for high-stakes clinical environments where cognitive load must be minimized to ensure patient safety. The brand personality is **authoritative, dependable, and transparent**, aimed at healthcare professionals including doctors, nurses, and laboratory technicians.

The aesthetic follows a **Refined Functionalist** approach—a blend of modern minimalism and systematic corporate design. It prioritizes information density without clutter, using generous whitespace to separate critical diagnostic data. The emotional response should be one of "calm focus," providing clinicians with the confidence that the data they are viewing is accurate and logically organized. High-contrast typography and a restrained use of color ensure that alerts and clinical pathways are immediately discernible.

## Colors

This design system utilizes a high-significance color palette designed for a clinical setting. 

*   **Primary Blue (#2563EB):** Used for primary actions, active states, and navigational anchors. It evokes trust and professional stability.
*   **Semantic Colors:** Success Green, Danger Red, and Warning Amber are strictly reserved for clinical status indicators (e.g., normal vs. critical lab results) and system alerts. 
*   **Neutrals:** A range of Slate grays is used for text and iconography to ensure varying levels of visual hierarchy.
*   **Surface Tones:** The interface relies on a "White on Subtle Gray" strategy. The main canvas is `#F9FAFB`, while interactive cards and content containers are pure `#FFFFFF` to create a clear "lift" from the background.

## Typography

The design system uses **Inter** exclusively due to its exceptional legibility and tall x-height, which is critical for reading patient records and medication dosages. 

### Key Rules:
*   **Numerical Data:** Use tabular figures (`tnum`) for all clinical measurements, lab values, and timestamps to ensure columns of numbers align perfectly for rapid scanning.
*   **Hierarchy:** Use `Title-LG` for card headers and `Label-MD` (all caps) for secondary metadata.
*   **Indonesian Localization:** Ensure line heights are sufficient to accommodate the specific ascenders and descenders common in Indonesian medical terminology.

## Layout & Spacing

The system employs a **12-column fluid grid** for desktop and a **single-column stack** for mobile. 

*   **Rhythm:** An 8px linear scale is used for all layout decisions, while a 4px scale is used for tight internal component spacing (e.g., icon to text).
*   **Card Layouts:** Information is grouped into discrete white cards. On desktop, secondary patient info (Vitals, Allergies) should occupy a 3 or 4-column side rail, while the primary clinical decision flow (Current Order, History) occupies the main 8-column span.
*   **Safe Areas:** Maintain a minimum 24px padding within all cards to ensure data does not feel cramped, aiding fast comprehension.

## Elevation & Depth

This design system avoids heavy shadows to maintain a clean, clinical feel. Depth is communicated through **Tonal Layering** and **Subtle Outlines**:

1.  **Level 0 (Background):** `#F9FAFB` - The base surface.
2.  **Level 1 (Cards/Containers):** `#FFFFFF` with a 1px solid border of `#E2E8F0`. No shadow.
3.  **Level 2 (Active/Hover):** `#FFFFFF` with a very soft, diffused shadow (0px 4px 12px rgba(0, 0, 0, 0.05)) and a Primary Blue border.
4.  **Level 3 (Modals/Popovers):** `#FFFFFF` with a 1px border and a medium shadow (0px 10px 25px rgba(0, 0, 0, 0.1)).

This approach ensures that the interface feels "flat yet structured," preventing visual fatigue during long shifts.

## Shapes

The design system uses a **Rounded** shape language to soften the industrial feel of clinical data.

*   **Standard Components:** Buttons, Input Fields, and Chips use a `0.5rem (8px)` radius.
*   **Containers:** Content cards and large modal overlays use a `1rem (16px)` or `1.5rem (24px)` radius to emphasize grouping.
*   **Selection Indicators:** Active states in navigation or list items use a 4px left-edge accent bar to supplement the rounded background.

## Components

### Buttons
*   **Primary:** Solid Primary Blue with white text. High contrast for critical actions (e.g., "Simpan Diagnosis").
*   **Secondary:** White background with 1px Slate-200 border and Slate-700 text.
*   **Ghost:** No border or background until hover; used for utility actions (e.g., "Batal").

### Chips & Badges
*   **Clinical Status:** Used for triage levels. Use semantic colors with 10% opacity backgrounds and 100% opacity text (e.g., Danger Red text on light pink background for "Kritis").

### Input Fields
*   Consistent 1px Slate-200 borders. Focus state uses a 2px Primary Blue ring. Labels should always be visible above the input, never as placeholders only.

### Cards
*   The primary unit of the UI. Must include a `Title-LG` header, 1px bottom border for the header section, and a clear "Action Area" at the bottom for related tasks.

### Data Tables
*   Used for lab results and medication history. Rows should have a subtle hover state (`#F1F5F9`) and zebra-striping is discouraged in favor of thin 1px horizontal dividers.

### Clinical Alerts
*   High-visibility banners that appear at the top of the patient record. They use the full semantic color (Warning/Danger) and include a clear icon to indicate the nature of the alert.